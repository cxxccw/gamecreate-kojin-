﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy2_m : MonoBehaviour
{
    public GameObject Enemy2;
    public float y = -1.5f;
    public float Enemy_Speed_x = 1f;
    public float Enemy_Speed_y = 1f;
    Rigidbody2D rb2d;
    public bool Enemy_2_U_ON = true;
    public bool Enemy_2_D_ON;
    // Start is called before the first frame update
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        Enemy2.transform.position = new Vector3(-1, -1.5f, 1.0f);
    }

    // Update is called once per frame
    void Update()
    {
        move();
 

    }
    void move()
    {
        if (Enemy_2_U_ON)
        {
            Enemy2.transform.position = new Vector3(-1, y, 1.0f);
            y += Enemy_Speed_y;
            if (y >= 5f)
            {
                Enemy_2_U_ON = false;
                Enemy_2_D_ON = true;
            }
        }
        
        if (Enemy_2_D_ON)
        {
            Enemy2.transform.position = new Vector3(-1, y, 1.0f);
            y -= Enemy_Speed_y;
            if (y <= -1.5f)
            {
                Enemy_2_U_ON = true;
                Enemy_2_D_ON = false;
            }
        }
        

    }



}




